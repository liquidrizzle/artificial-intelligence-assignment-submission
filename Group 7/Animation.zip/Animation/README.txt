# Mastermind AI Animation

This animation visually represents the recursive reasoning process described in the presentation.

## Description
- Displays guesses step by step
- Shows feedback evaluation
- Demonstrates how the AI narrows down possible solutions

## How to Run
Open `index.html` in a web browser.
No additional setup required.
